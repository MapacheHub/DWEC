// ==========================================================
// EJER_04.1 · Eventos en JavaScript
// Escribe aquí tus soluciones (módulo ES6).
// - Nombres de variables y funciones en español.
// - Usa addEventListener (no onclick en el HTML).
// ==========================================================

// ---------- Ejercicio 1 · Contador de clics ----------


// ---------- Ejercicio 2 · Tarjeta sensible al ratón ----------


// ---------- Ejercicio 3 · Espejo de texto ----------


// ---------- Ejercicio 4 · Mover con el teclado ----------


// ---------- Ejercicio 5 · Paleta de colores ----------


// ---------- Ejercicio 6 · Grupo con foco ----------


// ---------- Ejercicio 7 · Burbuja y captura ----------


// ---------- Ejercicio 8 · Detener y cancelar ----------
